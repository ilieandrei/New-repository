﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FiiActivApp.Models
{
    public class CourseModel
    {
        public int ID { get; set; }
        public string Titlu { get; set; }
        public string Descriere { get; set; }
        public int AnStudiu { get; set; }
        public int Semestru { get; set; }
        public int TipCurs { get; set; }
        public virtual ICollection<TeacherModel> Teachers { get; set; }
    }
}
