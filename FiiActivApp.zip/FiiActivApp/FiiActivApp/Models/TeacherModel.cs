﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FiiActivApp.Models
{
    public class TeacherModel
    {
        public int ID { get; set; }
        public string Nume { get; set; }
        public string Prenume { get; set; }
        public string Descriere { get; set; }
        [ForeignKey("CourseModel")]
        public CourseModel Curs { get; set; }
    }
}
